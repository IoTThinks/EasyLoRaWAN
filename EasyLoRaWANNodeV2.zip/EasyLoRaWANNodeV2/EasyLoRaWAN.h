// LoRaWAN frequency plan
// To define in Config.h of Beelan LoRaWAN

// LoRaWAN library: https://github.com/IoTThinks/Beelan-LoRaWAN/tree/Added-AS923-and-AS923-2
#include <lorawan.h>

// OTAA credentials
const char *devEui = "0000000000000000"; // TO CHANGE THIS VALUE
const char *appEui = "0000000000000000"; // Not in use for ChirpStack / Easy LoRaWAN Cloud
const char *appKey = "00000000000000000000000000000000"; // TO CHANGE THIS VALUE

const unsigned long interval = 10000;    // 10 s interval to send message
unsigned long previousMillis = 0;        // will store last time message sent
unsigned int counter = 0;                // message counter

char myStr[50];
char outStr[255];
byte recvStatus = 0;

const sRFM_pins RFM_pins = {
  .CS   = LORA_SS,
  .RST  = LORA_RESET,
  .DIO0 = LORA_DIO0,
  .DIO1 = LORA_DIO1,
  .DIO2 = LORA_DIO2, 
  .DIO5 = -1, // BOARD_DRAGINO_SHIELD only. Why we need DIO5 here?
};
